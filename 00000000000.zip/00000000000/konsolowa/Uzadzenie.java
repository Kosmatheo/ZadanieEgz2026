import javax.swing.*;
//********************************************************
// nazwa: Uzadzenie
// opis: Wyświtla komunikat podany w parametrze
// parametry: komunikatDoWyswietlenia - treść komunikatu do wyświetlenia
//
// zwracany typ i opis: metoda wypisuje treść komunikatu
// autor: 00000000000
//********************************************************
public class Uzadzenie {
    public void wyswietlkomunikat(String komunikatDoWyswietlenia) {
        System.out.println(komunikatDoWyswietlenia);
    }
}