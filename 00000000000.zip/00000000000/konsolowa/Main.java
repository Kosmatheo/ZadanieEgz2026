import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Pralka pralka = new Pralka();
        Odkurzacz odkurzacz = new Odkurzacz();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Numer prania: ");
        int nrPrania = scanner.nextInt();
        pralka.ustawNumerPrania(nrPrania);
        odkurzacz.on();
        odkurzacz.on();
        odkurzacz.on();
        odkurzacz.wyswietlkomunikat("odkurzacz się wyładował");
        odkurzacz.off();
    }
}