public class Pralka extends Uzadzenie {
    private int numerProgramu = 0;
    public int ustawNumerPrania(int nr){
        if(nr >= 0 && nr <= 12) {
            numerProgramu = nr;
            wyswietlkomunikat("Program został ustawiony");
        }
        else {
            numerProgramu = 0;
            wyswietlkomunikat("Podany niepoprawny numer programu");
        }
        return numerProgramu;
    }
}
