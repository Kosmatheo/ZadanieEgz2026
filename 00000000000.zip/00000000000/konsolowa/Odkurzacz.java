public class Odkurzacz extends  Uzadzenie {
    private boolean stan = false;
    public void on(){
        if(stan == false) {
            stan = true;
            wyswietlkomunikat("Odkurzacz włączony");
        }
    }
    public void off(){
        if(stan == true){
            stan = false;
            wyswietlkomunikat("Odkurzacz wyłączony");
        }
    }
}
